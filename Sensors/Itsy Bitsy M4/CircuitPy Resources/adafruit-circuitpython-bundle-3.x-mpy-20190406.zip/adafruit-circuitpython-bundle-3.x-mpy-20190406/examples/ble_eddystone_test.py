from adafruit_ble.beacon import EddystoneURLBeacon

beacon = EddystoneURLBeacon('https://adafru.it/4062')
beacon.start()
